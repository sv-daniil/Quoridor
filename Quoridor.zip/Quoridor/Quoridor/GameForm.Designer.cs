﻿namespace Quoridor
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm));
            panelOpenLog = new Panel();
            SuspendLayout();
            // 
            // panelOpenLog
            // 
            panelOpenLog.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panelOpenLog.BackColor = Color.FromArgb(64, 0, 0);
            panelOpenLog.Location = new Point(766, 2);
            panelOpenLog.Name = "panelOpenLog";
            panelOpenLog.Size = new Size(244, 214);
            panelOpenLog.TabIndex = 0;
            panelOpenLog.Click += panelOpenLog_Click;
            // 
            // GameForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(64, 0, 0);
            ClientSize = new Size(1012, 409);
            Controls.Add(panelOpenLog);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "GameForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quoridor";
            WindowState = FormWindowState.Maximized;
            Load += GameForm_Load;
            Shown += GameForm_Shown;
            ResumeLayout(false);

        }

        #endregion

        private Panel panelOpenLog;
    }
}