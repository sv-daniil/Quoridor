﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quoridor
{
    internal class HistoryIteration
    {
        public byte?[] y;
        public byte?[] x;
        public string?[] stocks;
        public byte? actual_player;
        public HistoryIteration(Player[] _players, Label[] _stocks, byte _actual_player, int current_move)
        {
            y = new byte?[4];
            x = new byte?[4];
            stocks = new string?[4];
            actual_player = new byte();

            actual_player = _actual_player;

            for (byte p = 0; p < 4; p++)
            {
                if (_players[p] is null)
                {
                    y[p] = null;
                    x[p] = null;
                    stocks[p] = null;
                }
                else
                {
                    y[p] = _players[p].Cell_Y;
                    x[p] = _players[p].Cell_X;
                    stocks[p] = _stocks[p].Text;
                }
            }
        }
    }
}
