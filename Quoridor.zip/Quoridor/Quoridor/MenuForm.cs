using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quoridor
{
    public partial class MenuForm : Form
    {
        private MenuPlayerCircle[] _menuPlayerCircles;
        private byte _number;
        private byte _numberOfPlayers;
        public byte Number
        {
            get { return _number; }
            set { _number = value; }
        }
        public byte NumberOfPlayers
        {
            get { return _numberOfPlayers; }
            set { _numberOfPlayers = value; }
        }

        public MenuForm()
        {
            InitializeComponent();
            Number = 0;
        }

        public void ChangeScreenData()
        {
            checkBox_Use.Checked = _menuPlayerCircles[Number].IsUsed;
            button_Color.Visible = checkBox_Use.Checked;
            button_Play.Visible = NumberOfPlayers > 1;

            foreach (MenuPlayerCircle circle in _menuPlayerCircles)
            {
                circle.Invalidate();
            }
        }

        private void SetImageWidth(PictureBox pb, int targetWidth)
        {
            Image img = pb.Image;

            // ��������� ����� ������ � ����������� ���������
            double aspectRatio = (double)img.Height / img.Width;
            int newHeight = (int)(targetWidth * aspectRatio);

            // ������ ������ PictureBox
            pb.Size = new Size(targetWidth, newHeight);
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            int panel_len = (int)(this.ClientSize.Height * 0.2);
            int player_len = panel_len * 5 / 8;
            int indent = (panel_len - player_len) / 2;
            int d = indent / 3;

            label_Quoridor.Font = new Font("Microsoft Sans Serif", (int)(this.ClientSize.Height * 0.1));
            label_Quoridor.Left = (int)(this.ClientSize.Width * 0.04);
            label_Quoridor.Top = (int)(this.ClientSize.Height * 0.03);

            label_v.Font = new Font("Microsoft Sans Serif", (int)(this.ClientSize.Height * 0.02));
            label_v.Left = label_Quoridor.Left + d * 5;
            label_v.Top = label_Quoridor.Bottom;

            panel.Size = new Size(panel_len, panel_len);
            panel.Left = label_Quoridor.Left + player_len + d * 3 + d * 3;
            panel.Top = label_Quoridor.Bottom + d * 3 + player_len + d;

            _menuPlayerCircles = new MenuPlayerCircle[4];

            _menuPlayerCircles[0] = new MenuPlayerCircle(player_len, panel.Left + indent, panel.Top - d - player_len, 0, this);
            _menuPlayerCircles[1] = new MenuPlayerCircle(player_len, panel.Left + panel.Width + d, panel.Top + indent, 1, this);
            _menuPlayerCircles[2] = new MenuPlayerCircle(player_len, panel.Left + indent, panel.Top + panel.Height + d, 2, this);
            _menuPlayerCircles[3] = new MenuPlayerCircle(player_len, panel.Left - d - player_len, panel.Top + indent, 3, this);
            for (int i = 0; i < 4; i++)
            {
                this.Controls.Add(_menuPlayerCircles[i]);
            }
            checkBox_Use.Checked = _menuPlayerCircles[Number].IsUsed;


            Font menuButtonsFont = new Font("Microsoft Sans Serif", (int)(this.ClientSize.Height * 0.03));
            checkBox_Use.Font = menuButtonsFont;
            button_Color.Font = menuButtonsFont;
            button_Play.Font = menuButtonsFont;
            checkBox_Use.Left = label_Quoridor.Left + d * 3;
            button_Color.Left = d * 2 + checkBox_Use.Left;
            button_Color.Top = this.ClientSize.Height - d * 3 - button_Color.Height;
            checkBox_Use.Top = button_Color.Top - d * 3 - checkBox_Use.Height;
            button_Play.Top = checkBox_Use.Top + d * 3;
            button_Play.Left = label_Quoridor.Right - d * 3 - button_Play.Width;
            button_Color.AutoSize = true;
            button_Play.AutoSize = true;

            panel_Instruction.Width = this.ClientSize.Width - label_Quoridor.Right - d * 3 - d * 3;
            panel_Instruction.Height = this.ClientSize.Height - d * 3 - d * 3;
            panel_Instruction.Left = label_Quoridor.Right + (this.ClientSize.Width - label_Quoridor.Right) / 2 - (panel_Instruction.Width) / 2;
            panel_Instruction.Top = this.ClientSize.Height / 2 - panel_Instruction.Height / 2;
            panel_Instruction.BackColor = Color.FromArgb(255, 224, 192);
            panel_Instruction.AutoScroll = true;

            PictureBox Instruction = new PictureBox();
            panel_Instruction.Controls.Add(Instruction);
            Instruction.Location = new Point(0, 0);
            Instruction.Image = (Image)Properties.Resources.ResourceManager.GetObject("Instruction");
            SetImageWidth(Instruction, Instruction.Parent.Width);

            checkBox_Use_CheckedChanged(null, null);
            ChangeScreenData();
        }
        private void checkBox_Use_CheckedChanged(object sender, EventArgs e)
        {
            _menuPlayerCircles[Number].IsUsed = checkBox_Use.Checked;

            NumberOfPlayers = 0;
            for (int i = 0; i < 4; i++)
            {
                if (_menuPlayerCircles[i].IsUsed)
                {
                    NumberOfPlayers++;
                }
            }

            ChangeScreenData();
        }
        private void button_Color_Click(object sender, EventArgs e)
        {
            ColorDialog clrDialog = new ColorDialog();
            if (clrDialog.ShowDialog() == DialogResult.OK)
                _menuPlayerCircles[Number].Clr = clrDialog.Color;
            ChangeScreenData();
        }
        private void button_Play_Click(object sender, EventArgs e)
        {
            Color?[] dataForStart = new Color?[4];
            for (int i = 0; i < 4; i++)
            {
                if (_menuPlayerCircles[i].IsUsed)
                    dataForStart[i] = _menuPlayerCircles[i].Clr;
                else
                    dataForStart[i] = null;
            }

            this.Hide();
            (new GameForm(dataForStart, NumberOfPlayers)).ShowDialog();
            
            //this.Close();
            Application.Restart();
        }
    }
}