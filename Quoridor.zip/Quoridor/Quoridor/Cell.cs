﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quoridor
{
    internal class Cell : System.Windows.Forms.Panel
    {
        private bool _rightWall;
        private bool _bottomWall;
        private bool _rightBlocked;
        private bool _bottomBlocked;
        private bool _player;
        private bool _isPawnMovePossible;
        public bool RightWall
        {
            get { return _rightWall; }
            set { _rightWall = value; }
        }
        public bool BottomtWall
        {
            get { return _bottomWall; }
            set { _bottomWall = value; }
        }
        public bool RightBlocked
        {
            get { return _rightBlocked; }
            set { _rightBlocked = value; }
        }
        public bool BottomBlocked
        {
            get { return _bottomBlocked; }
            set { _bottomBlocked = value; }
        }
        public bool Player
        {
            get { return _player; }
            set { _player = value; }
        }
        public bool IsPawnMovePossible
        {
            get { return _isPawnMovePossible; }
            set { _isPawnMovePossible = value; }
        }


        public Cell(byte x, byte y)
        {
            Player = false;

            if (x == 8)
                RightWall = true;
            else
                RightWall = false;

            if (y == 8)
                BottomtWall = true;
            else
                BottomtWall = false;

            RightBlocked = RightWall;
            BottomBlocked = BottomtWall;
        }
    }
}