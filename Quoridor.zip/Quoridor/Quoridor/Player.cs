﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quoridor
{
    internal class Player : System.Windows.Forms.Panel
    {
        private byte _number;
        private byte _nominalNumber;
        private GameForm _callingForm;
        private byte _cell_x;
        private byte _cell_y;
        private int _indent;
        public byte Number
        {
            get { return _number; }
            set { _number = value; }
        }
        public byte NominalNumber
        {
            get { return _nominalNumber; }
            set { _nominalNumber = value; }
        }
        public GameForm CallingForm
        {
            get { return _callingForm; }
            set { _callingForm = value; }
        }
        public byte Cell_X
        {
            get { return _cell_x; }
            set { _cell_x = value; }
        }
        public byte Cell_Y
        {
            get { return _cell_y; }
            set { _cell_y = value; }
        }
        public int Indent
        {
            get { return _indent; }
            set { _indent = value; }
        }


        public Player(byte number, byte nominal_number, Color clr, GameForm callingForm, ref Cell[,] cells)
        {
            Number = number;
            NominalNumber = nominal_number;
            BackColor = clr;
            CallingForm = callingForm;

            int len = (int)(CallingForm.Len * 0.8);
            Indent = (CallingForm.Len - len) / 2;
            Size = new Size(len, len);

            switch (Number)
            {
                case 0: Cell_X = 4; Cell_Y = 0; break;
                case 1: Cell_X = 8; Cell_Y = 4; break;
                case 2: Cell_X = 4; Cell_Y = 8; break;
                case 3: Cell_X = 0; Cell_Y = 4; break;
            }

            //switch (Number) // delete this thing
            //{
            //    case 0: Cell_X = 4; Cell_Y = 7; break;
            //    case 1: Cell_X = 1; Cell_Y = 4; break;
            //    case 2: Cell_X = 4; Cell_Y = 1; break;
            //    case 3: Cell_X = 7; Cell_Y = 4; break;
            //}

            cells[Cell_Y, Cell_X].Player = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Color strokeColor = Color.White;
            byte strokeSize = 4;
            if (CallingForm.ActualPlayer == Number)
            {
                strokeColor = Color.Yellow;
                strokeSize = 8;
            }

            this.Location = new System.Drawing.Point(CallingForm.DeskLeft + Cell_X * (CallingForm.Len + CallingForm.D) + Indent,
                                                     CallingForm.DeskTop + Cell_Y * (CallingForm.Len + CallingForm.D) + Indent);

            Graphics g = e.Graphics;

            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, Width, Height);
            this.Region = new System.Drawing.Region(path);

            g.FillEllipse(new SolidBrush(BackColor), 0, 0, Width, Height);
            g.DrawEllipse(new Pen(strokeColor, strokeSize), 0, 0, Width, Height);
        }
    }
}