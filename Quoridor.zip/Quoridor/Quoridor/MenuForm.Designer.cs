﻿namespace Quoridor
{
    partial class MenuForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            label_Quoridor = new Label();
            button_Play = new Button();
            panel = new Panel();
            button_Color = new Button();
            checkBox_Use = new CheckBox();
            panel_Instruction = new Panel();
            label_v = new Label();
            SuspendLayout();
            // 
            // label_Quoridor
            // 
            label_Quoridor.AutoSize = true;
            label_Quoridor.Font = new Font("Microsoft Sans Serif", 48F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label_Quoridor.ForeColor = Color.FromArgb(255, 224, 192);
            label_Quoridor.Location = new Point(-4, 9);
            label_Quoridor.Name = "label_Quoridor";
            label_Quoridor.Size = new Size(356, 91);
            label_Quoridor.TabIndex = 0;
            label_Quoridor.Text = "Quoridor";
            // 
            // button_Play
            // 
            button_Play.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button_Play.BackColor = Color.FromArgb(255, 224, 192);
            button_Play.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button_Play.ForeColor = Color.FromArgb(64, 0, 0);
            button_Play.Location = new Point(327, 568);
            button_Play.Name = "button_Play";
            button_Play.Size = new Size(115, 49);
            button_Play.TabIndex = 3;
            button_Play.Text = "Play";
            button_Play.UseVisualStyleBackColor = false;
            button_Play.Click += button_Play_Click;
            // 
            // panel
            // 
            panel.BackColor = Color.Maroon;
            panel.Location = new Point(92, 167);
            panel.Name = "panel";
            panel.Size = new Size(80, 80);
            panel.TabIndex = 2;
            // 
            // button_Color
            // 
            button_Color.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            button_Color.BackColor = Color.FromArgb(64, 0, 0);
            button_Color.FlatStyle = FlatStyle.Flat;
            button_Color.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button_Color.ForeColor = Color.FromArgb(255, 224, 192);
            button_Color.Location = new Point(61, 602);
            button_Color.Name = "button_Color";
            button_Color.Size = new Size(96, 37);
            button_Color.TabIndex = 2;
            button_Color.Text = "Color";
            button_Color.UseVisualStyleBackColor = false;
            button_Color.Click += button_Color_Click;
            // 
            // checkBox_Use
            // 
            checkBox_Use.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            checkBox_Use.AutoSize = true;
            checkBox_Use.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            checkBox_Use.ForeColor = Color.FromArgb(255, 224, 192);
            checkBox_Use.Location = new Point(36, 568);
            checkBox_Use.Name = "checkBox_Use";
            checkBox_Use.Size = new Size(203, 33);
            checkBox_Use.TabIndex = 1;
            checkBox_Use.Text = "Use the player";
            checkBox_Use.UseVisualStyleBackColor = true;
            checkBox_Use.CheckedChanged += checkBox_Use_CheckedChanged;
            // 
            // panel_Instruction
            // 
            panel_Instruction.Location = new Point(602, 42);
            panel_Instruction.Name = "panel_Instruction";
            panel_Instruction.Size = new Size(292, 176);
            panel_Instruction.TabIndex = 4;
            // 
            // label_v
            // 
            label_v.AutoSize = true;
            label_v.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
            label_v.ForeColor = Color.FromArgb(255, 224, 192);
            label_v.Location = new Point(23, 100);
            label_v.Name = "label_v";
            label_v.Size = new Size(71, 25);
            label_v.TabIndex = 5;
            label_v.Text = "v1.0.0";
            // 
            // MenuForm
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.FromArgb(64, 0, 0);
            ClientSize = new Size(1006, 657);
            Controls.Add(label_v);
            Controls.Add(panel_Instruction);
            Controls.Add(checkBox_Use);
            Controls.Add(button_Color);
            Controls.Add(panel);
            Controls.Add(button_Play);
            Controls.Add(label_Quoridor);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "MenuForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quoridor";
            WindowState = FormWindowState.Maximized;
            Load += MainForm_Load;
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Quoridor;
        private System.Windows.Forms.Button button_Play;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Button button_Color;
        private System.Windows.Forms.CheckBox checkBox_Use;
        private Panel panel_Instruction;
        private Label label_v;
    }
}

