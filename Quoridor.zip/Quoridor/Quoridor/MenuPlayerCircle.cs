﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quoridor
{
    internal class MenuPlayerCircle : System.Windows.Forms.Button
    {
        private byte _number;
        private Color _clr;
        private MenuForm _callingForm;
        private bool _isUsed;
        public byte Number
        {
            get { return _number; }
            set { _number = value; }
        }
        public Color Clr
        {
            get { return _clr; }
            set { _clr = value; }
        }
        public MenuForm CallingForm
        {
            get { return _callingForm; }
            set { _callingForm = value; }
        }
        public bool IsUsed
        {
            get { return _isUsed; }
            set { _isUsed = value; }
        }

        public MenuPlayerCircle(int player_len, int x, int y, byte number, MenuForm callingForm)
        {
            this.CallingForm = callingForm;
            int len = player_len;
            this.Location = new System.Drawing.Point(x, y);
            this.Size = new System.Drawing.Size(len, len);
            this.Number = number;
            this.Click += this_Click;

            switch (number)
            {
                case 0:
                    this.IsUsed = false;
                    break;
                case 1:
                    this.IsUsed = true;
                    break;
                case 2:
                    this.IsUsed = false;
                    break;
                case 3:
                    this.IsUsed = true;
                    break;
            }

            Random rand = new Random();
            this.Clr = Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255));
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Color strokeColor;
            byte strokeSize;
            Color backColor;

            if (CallingForm.Number == this.Number)
            {
                strokeColor = Color.Yellow;
                strokeSize = 24;
            }
            else
            {
                strokeSize = 8;
                if (IsUsed)
                    strokeColor = Color.White;
                else
                    strokeColor = Color.Black;
            }

            if (IsUsed)
                backColor = Clr;
            else
                backColor = Color.FromArgb(64, 0, 0);


            Graphics g = e.Graphics;

            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, Width, Height);
            this.Region = new System.Drawing.Region(path);

            g.FillEllipse(new SolidBrush(backColor), 0, 0, Width, Height);
            g.DrawEllipse(new Pen(strokeColor, strokeSize), 0, 0, Width, Height);
        }

        private void this_Click(object sender, EventArgs e)
        {
            CallingForm.Number = this.Number;
            CallingForm.ChangeScreenData();
        }
    }
}