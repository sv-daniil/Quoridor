﻿using Microsoft.VisualBasic.Devices;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quoridor
{
    public partial class GameForm : Form
    {
        private Panel _MoveChooser;
        private List<Panel> _walls;
        private Cell[,] _cells;
        private Label[] _stocks;
        private List<HistoryIteration> _history;
        private Color?[] _playersDataForStart;
        private Player[] _players;
        private byte _numberOfPlayers;
        private int _len;
        private int _d;
        private int _desk_len;
        private int _desk_left;
        private int _desk_top;
        private byte _actualPlayer;
        private int _current_move;
        private Label MessagesLabel;
        private ComboBox comboBox_Move;
        private CancellationTokenSource _cts;
        public byte NumberOfPlayers
        {
            get { return _numberOfPlayers; }
            set { _numberOfPlayers = value; }
        }
        public int Len
        {
            get { return _len; }
            set { _len = value; }
        }
        public int D
        {
            get { return _d; }
            set { _d = value; }
        }
        public int DeskLen
        {
            get { return _desk_len; }
            set { _desk_len = value; }
        }
        public int DeskLeft
        {
            get { return _desk_left; }
            set { _desk_left = value; }
        }
        public int DeskTop
        {
            get { return _desk_top; }
            set { _desk_top = value; }
        }
        public byte ActualPlayer
        {
            get { return _actualPlayer; }
            set { _actualPlayer = value; }
        }
        public int CurrentMove
        {
            get { return _current_move; }
            set { _current_move = value; }
        }


        public GameForm(Color?[] pD, byte nOP)
        {
            InitializeComponent();
            _playersDataForStart = pD;
            NumberOfPlayers = nOP;
        }

        public void OriginalData(byte num) // ------------ delete ------------
        {
            MessageBox.Show($"{_players[num].Cell_X}");
        }
        public void Log(int CURRENT_MOVE)
        {
            using (FileStream f = new FileStream("log.html", FileMode.Create))
            using (StreamWriter writer = new StreamWriter(f, Encoding.UTF8))
            {
                writer.Write("<code><pre>");
                writer.Write($"Current move: {CURRENT_MOVE}<br>Actual player: {ActualPlayer}<br><br>");

                for (byte j = 0; j < 9; j++)
                {
                    for (byte i = 0; i < 9; i++)
                    {
                        if (_cells[j, i].Player)
                        {
                            for (byte p = 0; p < 4; p++)
                            {
                                if (!(_players[p] is null) && _players[p].Cell_X == i && _players[p].Cell_Y == j)
                                {
                                    writer.Write($"{p}");
                                    p = 4;
                                }
                            }
                        }
                        else if (_cells[j, i].IsPawnMovePossible)
                            writer.Write("@");
                        else
                            writer.Write("*"); // *
                        writer.Write(_cells[j, i].RightBlocked ? "|" : " ");
                    }
                    writer.Write("<br>");

                    for (byte i = 0; i < 9; i++)
                    {
                        writer.Write($"{(_cells[j, i].BottomBlocked ? "—" : " ")} ");
                    }
                    writer.Write("<br>");
                }

                writer.Write("</pre></code>");
                writer.Flush();
            }
        }


        public string FromCellToSide(byte cell_x, byte cell_y, char side)
        {
            string answer = "wall";

            switch (side)
            {
                case '^':
                    if (cell_y > 0 && !_cells[cell_y - 1, cell_x].BottomBlocked)
                    {
                        if (_cells[cell_y - 1, cell_x].Player)
                            answer = "player";
                        else
                            answer = "free";
                    }
                    break;
                case '<':
                    if (cell_x > 0 && !_cells[cell_y, cell_x - 1].RightBlocked)
                    {
                        if (_cells[cell_y, cell_x - 1].Player)
                            answer = "player";
                        else
                            answer = "free";
                    }
                    break;
                case '_':
                    if (!_cells[cell_y, cell_x].BottomBlocked)
                    {
                        if (_cells[cell_y + 1, cell_x].Player)
                            answer = "player";
                        else
                            answer = "free";
                    }
                    break;
                case '>':
                    if (!_cells[cell_y, cell_x].RightBlocked)
                    {
                        if (_cells[cell_y, cell_x + 1].Player)
                            answer = "player";
                        else
                            answer = "free";
                    }
                    break;
            }

            return answer;
        }

        private void SetPossiblePawnMoves()
        {
            byte pc_x = _players[ActualPlayer].Cell_X;
            byte pc_y = _players[ActualPlayer].Cell_Y;
            byte number_of_possible_pawn_moves = 0;

            for (int j = 0; j < 9; j++)
            {
                for (int i = 0; i < 9; i++)
                {
                    _cells[j, i].IsPawnMovePossible = false;
                }
            }

            // ^
            switch (FromCellToSide(pc_x, pc_y, '^'))
            {
                case "free":
                    _cells[pc_y - 1, pc_x].IsPawnMovePossible = true;
                    number_of_possible_pawn_moves++;
                    break;
                case "player":
                    if (FromCellToSide(pc_x, (byte)(pc_y - 1), '^') == "free")
                    {
                        _cells[pc_y - 2, pc_x].IsPawnMovePossible = true;
                        number_of_possible_pawn_moves++;
                    }
                    else
                    {
                        if (FromCellToSide(pc_x, (byte)(pc_y - 1), '<') == "free")
                        {
                            _cells[pc_y - 1, pc_x - 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                        if (FromCellToSide(pc_x, (byte)(pc_y - 1), '>') == "free")
                        {
                            _cells[pc_y - 1, pc_x + 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                    }
                    break;
            }

            // <
            switch (FromCellToSide(pc_x, pc_y, '<'))
            {
                case "free":
                    _cells[pc_y, pc_x - 1].IsPawnMovePossible = true;
                    number_of_possible_pawn_moves++;
                    break;
                case "player":
                    if (FromCellToSide((byte)(pc_x - 1), pc_y, '<') == "free")
                    {
                        _cells[pc_y, pc_x - 2].IsPawnMovePossible = true;
                        number_of_possible_pawn_moves++;
                    }
                    else
                    {
                        if (FromCellToSide((byte)(pc_x - 1), pc_y, '^') == "free")
                        {
                            _cells[pc_y - 1, pc_x - 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                        if (FromCellToSide((byte)(pc_x - 1), pc_y, '_') == "free")
                        {
                            _cells[pc_y + 1, pc_x - 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                    }
                    break;
            }

            // _
            switch (FromCellToSide(pc_x, pc_y, '_'))
            {
                case "free":
                    _cells[pc_y + 1, pc_x].IsPawnMovePossible = true;
                    number_of_possible_pawn_moves++;
                    break;
                case "player":
                    if (FromCellToSide(pc_x, (byte)(pc_y + 1), '_') == "free")
                    {
                        _cells[pc_y + 2, pc_x].IsPawnMovePossible = true;
                        number_of_possible_pawn_moves++;
                    }
                    else
                    {
                        if (FromCellToSide(pc_x, (byte)(pc_y + 1), '<') == "free")
                        {
                            _cells[pc_y + 1, pc_x - 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                        if (FromCellToSide(pc_x, (byte)(pc_y + 1), '>') == "free")
                        {
                            _cells[pc_y + 1, pc_x + 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                    }
                    break;
            }

            // >
            switch (FromCellToSide(pc_x, pc_y, '>'))
            {
                case "free":
                    _cells[pc_y, pc_x + 1].IsPawnMovePossible = true;
                    number_of_possible_pawn_moves++;
                    break;
                case "player":
                    if (FromCellToSide((byte)(pc_x + 1), pc_y, '>') == "free")
                    {
                        _cells[pc_y, pc_x + 2].IsPawnMovePossible = true;
                        number_of_possible_pawn_moves++;
                    }
                    else
                    {
                        if (FromCellToSide((byte)(pc_x + 1), pc_y, '^') == "free")
                        {
                            _cells[pc_y - 1, pc_x + 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                        if (FromCellToSide((byte)(pc_x + 1), pc_y, '_') == "free")
                        {
                            _cells[pc_y + 1, pc_x + 1].IsPawnMovePossible = true;
                            number_of_possible_pawn_moves++;
                        }
                    }
                    break;
            }

            if (number_of_possible_pawn_moves == 0 && _stocks[ActualPlayer].Text == "0")
            {
                MessageBoxIcon icon = MessageBoxIcon.Exclamation;
                MessageBox.Show("Congratulations!", "", MessageBoxButtons.OK, icon);
                MessageBox.Show($"You have created a situation in which player {_players[ActualPlayer].NominalNumber} can't move.", "", MessageBoxButtons.OK, icon);
                MessageBox.Show("It's really hard to do this in a game where locking players by walls is prohibited.", "", MessageBoxButtons.OK, icon);
                MessageBox.Show("May be you even know that such situation isn't provided in the rules.", "", MessageBoxButtons.OK, icon);
                MessageBox.Show("So, okay. Do whatever you want now.", "", MessageBoxButtons.OK, icon);
            }
        }

        public async Task LockingWarning()
        {
            int previous_x = MessagesLabel.Left;
            MessagesLabel.Text = "Locking players is prohibited!";
            MessagesLabel.Left = this.ClientSize.Width / 2 - MessagesLabel.Width / 2;
            MessagesLabel.ForeColor = Color.FromArgb(255, 192, 192);
            MessagesLabel.Visible = true;
            await Task.Delay(1000);
            MessagesLabel.Visible = false;
            MessagesLabel.Left = previous_x;
        }

        public void MoveResults(byte cell_x, byte cell_y, byte TypeOfMove)
        {
            byte num;

            switch (TypeOfMove)
            {
                case 0:
                    _cells[cell_y, cell_x].RightWall = true;
                    _cells[cell_y, cell_x].RightBlocked = true;
                    _cells[cell_y + 1, cell_x].RightBlocked = true;
                    goto case 254;
                case 1:
                    _cells[cell_y, cell_x].BottomtWall = true;
                    _cells[cell_y, cell_x].BottomBlocked = true;
                    _cells[cell_y, cell_x + 1].BottomBlocked = true;
                    goto case 254;

                case 254:
                    _walls.Add(new Panel());
                    num = (byte)(_walls.Count - 1);
                    _stocks[ActualPlayer].Text = Convert.ToString(Byte.Parse(_stocks[ActualPlayer].Text) - 1);

                    _walls[num].Left = _MoveChooser.Left;
                    _walls[num].Top = _MoveChooser.Top;
                    _walls[num].Width = _MoveChooser.Width;
                    _walls[num].Height = _MoveChooser.Height;
                    _walls[num].BackColor = _players[ActualPlayer].BackColor;
                    _walls[num].Tag = CurrentMove;
                    this.Controls.Add(_walls[num]);

                    break;

                case 2:
                    _cells[_players[ActualPlayer].Cell_Y, _players[ActualPlayer].Cell_X].Player = false;
                    _cells[cell_y, cell_x].Player = true;
                    _players[ActualPlayer].Cell_X = cell_x;
                    _players[ActualPlayer].Cell_Y = cell_y;
                    break;
            }
        }

        private async Task PlayerChoosesMove(CancellationToken token)
        {
            bool IsMovePossible = false;
            byte TypeOfMove = 255;

            while (true)
            {
                Point mouse = this.PointToClient(Control.MousePosition);
                byte cell_x = (byte)((mouse.X - DeskLeft) / (Len + D));
                byte cell_y = (byte)((mouse.Y - DeskTop) / (Len + D));

                IsMovePossible = false;

                if ((DeskLeft <= mouse.X && mouse.X <= DeskLeft + DeskLen) &&
                    (DeskTop <= mouse.Y && mouse.Y <= DeskTop + DeskLen))
                {
                    byte player_cell_x = _players[ActualPlayer].Cell_X;
                    byte player_cell_y = _players[ActualPlayer].Cell_Y;

                    /* move:
                     0) ver wall
                     1) hor wall
                     2) pawn move
                    */

                    if (/* 2 */
                        _cells[cell_y, cell_x].IsPawnMovePossible &&
                        mouse.X < DeskLeft + cell_x * (Len + D) + Len &&
                        mouse.Y < DeskTop + cell_y * (Len + D) + Len)
                    {
                        IsMovePossible = true;
                        _MoveChooser.Left = DeskLeft + cell_x * (Len + D);
                        _MoveChooser.Top = DeskTop + cell_y * (Len + D);
                        _MoveChooser.Width = Len;
                        _MoveChooser.Height = Len;
                        TypeOfMove = 2;
                    }

                    /* for check:
                     LOCKING SM PLAYER
                    */
                    else if (/* 0 vertical */
                        !(_cells[cell_y, cell_x].RightBlocked) &&
                        !(_cells[cell_y, cell_x].BottomtWall) &&
                        !(_cells[cell_y + 1, cell_x].RightBlocked) &&
                        _stocks[ActualPlayer].Text != "0" &&
                        DeskLeft + cell_x * (Len + D) + Len <= mouse.X &&
                        mouse.Y <= DeskTop + cell_y * (Len + D) + Len)
                    {
                        IsMovePossible = true;
                        _MoveChooser.Left = DeskLeft + cell_x * (Len + D) + Len;
                        _MoveChooser.Top = DeskTop + cell_y * (Len + D);
                        _MoveChooser.Width = D;
                        _MoveChooser.Height = Len + D + Len;
                        TypeOfMove = 0;
                    }

                    else if (/* 1 horizontal */
                        !(_cells[cell_y, cell_x].BottomBlocked) &&
                        !(_cells[cell_y, cell_x].RightWall) &&
                        !(_cells[cell_y, cell_x + 1].BottomBlocked) &&
                        _stocks[ActualPlayer].Text != "0" &&
                        DeskTop + cell_y * (Len + D) + Len <= mouse.Y &&
                        mouse.X <= DeskLeft + cell_x * (Len + D) + Len)
                    {
                        IsMovePossible = true;
                        _MoveChooser.Left = DeskLeft + cell_x * (Len + D);
                        _MoveChooser.Top = DeskTop + cell_y * (Len + D) + Len;
                        _MoveChooser.Width = Len + D + Len;
                        _MoveChooser.Height = D;
                        TypeOfMove = 1;
                    }
                }

                _MoveChooser.Visible = IsMovePossible;

                try
                {
                    await Task.Delay(150, token);
                }
                catch
                {
                    //if (TypeOfMove < 2 &&
                    //    (WallLockingCanceler.IsPlayerLocked(this, _players[0], _cells, cell_x, cell_y, TypeOfMove) ||
                    //     WallLockingCanceler.IsPlayerLocked(this, _players[1], _cells, cell_x, cell_y, TypeOfMove) ||
                    //     WallLockingCanceler.IsPlayerLocked(this, _players[2], _cells, cell_x, cell_y, TypeOfMove) ||
                    //     WallLockingCanceler.IsPlayerLocked(this, _players[3], _cells, cell_x, cell_y, TypeOfMove)))
                    //{
                    //    LockingWarning();
                    //}
                    //else
                    //{
                        _MoveChooser.Visible = false;
                        MoveResults(cell_x, cell_y, TypeOfMove);
                        return;
                    //}
                }
            }
        }

        private async Task ShowIfPlayerWins()
        {
            if ((ActualPlayer == 0 && _players[ActualPlayer].Cell_Y == 8) ||
                (ActualPlayer == 1 && _players[ActualPlayer].Cell_X == 0) ||
                (ActualPlayer == 2 && _players[ActualPlayer].Cell_Y == 0) ||
                (ActualPlayer == 3 && _players[ActualPlayer].Cell_X == 8))
            {
                MessagesLabel.Text = $"Player {_players[ActualPlayer].NominalNumber} wins!";
                MessagesLabel.ForeColor = _players[ActualPlayer].BackColor;
                MessagesLabel.Visible = true;
                await Task.Delay(2400); // await Task.Delay(20);

                _players[ActualPlayer].Visible = false;
                _stocks[ActualPlayer].Visible = false;
                _players[ActualPlayer] = null;
                
                NumberOfPlayers--;
                MessagesLabel.Visible = false;
            }
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            double full_cell_len = this.ClientSize.Height * 0.85 / 9;
            Len = (int)(full_cell_len * 0.8);
            D = (int)(full_cell_len * 0.2);

            DeskLen = Len * 9 + D * 8;
            DeskLeft = this.ClientSize.Width / 2 - DeskLen / 2;
            DeskTop = this.ClientSize.Height / 2 - DeskLen / 2;

            _walls = new List<Panel>();

            _stocks = new Label[4];
            byte stocksForEveryPlayer;
            switch (NumberOfPlayers)
            {
                case 1: stocksForEveryPlayer = 20; break;
                case 2: stocksForEveryPlayer = 10; break;
                case 3: stocksForEveryPlayer = 7; break;
                case 4: stocksForEveryPlayer = 6; break;
                default: stocksForEveryPlayer = 0; break;
            }
            for (int i = 0; i < 4; i++)
            {
                if (_playersDataForStart[i] is null)
                {
                    _stocks[i] = null;
                }
                else
                {
                    _stocks[i] = new Label();
                    _stocks[i].Text = Convert.ToString(stocksForEveryPlayer);

                    _stocks[i].Font = new Font("Microsoft Sans Serif", 20, FontStyle.Bold);
                    _stocks[i].ForeColor = Color.Maroon;
                    _stocks[i].TextAlign = ContentAlignment.MiddleCenter;
                    _stocks[i].AutoSize = true;
                    this.Controls.Add(_stocks[i]);

                    switch (i)
                    {
                        case 0:
                            _stocks[i].Left = this.ClientSize.Width / 2 - _stocks[i].Width / 2;
                            _stocks[i].Top = DeskTop - D - _stocks[i].Height;
                            break;
                        case 1:
                            _stocks[i].Left = this.ClientSize.Width / 2 + DeskLen / 2 + D;
                            _stocks[i].Top = this.ClientSize.Height / 2 - _stocks[i].Height / 2;
                            break;
                        case 2:
                            _stocks[i].Left = this.ClientSize.Width / 2 - _stocks[i].Width / 2;
                            _stocks[i].Top = DeskTop + DeskLen + D;
                            break;
                        case 3:
                            _stocks[i].Left = this.ClientSize.Width / 2 - DeskLen / 2 - D - _stocks[i].Width;
                            _stocks[i].Top = this.ClientSize.Height / 2 - _stocks[i].Height / 2;
                            break;
                    }
                }
            }

            _cells = new Cell[9, 9];
            for (byte j = 0; j < 9; j++)
            {
                for (byte i = 0; i < 9; i++)
                {
                    _cells[j, i] = new Cell(i, j);
                    _cells[j, i].Size = new Size(Len, Len);
                    _cells[j, i].BackColor = Color.Maroon;
                    _cells[j, i].Location = new Point(DeskLeft + i * (Len + D), DeskTop + j * (Len + D));
                    this.Controls.Add(_cells[j, i]);
                }
            }

            _MoveChooser = new Panel();
            _MoveChooser.Visible = false;
            _MoveChooser.BackColor = Color.Yellow;
            this.Controls.Add(_MoveChooser);
            _MoveChooser.BringToFront();
            _MoveChooser.Click += _MoveChooser_Click;

            _players = new Player[4];
            int nominal_number = 1;
            for (byte i = 0; i < 4; i++)
            {
                if (_playersDataForStart[i] is null)
                    _players[i] = null;
                else
                {
                    _players[i] = new Player(i, (byte)(nominal_number)++, (Color)(_playersDataForStart[i]), this, ref _cells);
                    this.Controls.Add(_players[i]);
                    _players[i].BringToFront();
                }
            }

            MessagesLabel = new Label();
            MessagesLabel.Visible = false;
            MessagesLabel.Font = new Font("Microsoft Sans Serif", (int)(DeskTop * 0.4), FontStyle.Bold);
            MessagesLabel.Text = "Player 0 wins!";
            MessagesLabel.TextAlign = ContentAlignment.TopLeft;
            MessagesLabel.AutoSize = true;
            this.Controls.Add(MessagesLabel);
            MessagesLabel.BringToFront();
            MessagesLabel.Left = this.ClientSize.Width / 2 - MessagesLabel.Width / 2;
            MessagesLabel.Top = DeskTop / 2 - MessagesLabel.Height / 2;

            _history = new List<HistoryIteration>();

            comboBox_Move = new ComboBox();
        }


        private async void GameForm_Shown(object sender, EventArgs e)
        {
            ActualPlayer = 3;
            byte lastPlayer;
            CurrentMove = 0;

            _history.Add(new HistoryIteration(_players, _stocks, 4, CurrentMove));
            while (NumberOfPlayers > 1)
            {
                do
                {
                    ActualPlayer++;
                    if (ActualPlayer > 3)
                        ActualPlayer = 0;
                }
                while (_players[ActualPlayer] is null);
                SetPossiblePawnMoves();
                CurrentMove++;
                //Log(CurrentMove);
                await Task.Delay(300);

                _stocks[ActualPlayer].BackColor = _players[ActualPlayer].BackColor;
                _stocks[ActualPlayer].ForeColor = Color.FromArgb(64, 0, 0);
                _players[ActualPlayer].Invalidate();
                _cts = new CancellationTokenSource();
                await PlayerChoosesMove(_cts.Token);

                _stocks[ActualPlayer].BackColor = Color.FromArgb(64, 0, 0);
                _stocks[ActualPlayer].ForeColor = Color.Maroon;
                lastPlayer = ActualPlayer;
                ActualPlayer = 255;
                _players[lastPlayer].Invalidate();
                await Task.Delay(50);
                ActualPlayer = lastPlayer;
                _history.Add(new HistoryIteration(_players, _stocks, ActualPlayer, CurrentMove));
                await ShowIfPlayerWins();
            }
            
            MessagesLabel.Text = "THE END";
            MessagesLabel.Font = new Font("Microsoft Sans Serif", (int)(this.ClientSize.Height * 0.1));
            MessagesLabel.ForeColor = Color.Wheat;
            MessagesLabel.Left = this.ClientSize.Width / 2 - MessagesLabel.Width / 2;
            MessagesLabel.Top = this.ClientSize.Height / 2 - MessagesLabel.Height / 2;
            MessagesLabel.Visible = true;
            await Task.Delay(3000); // await Task.Delay(10);
            MessagesLabel.Visible = false;

            for (byte p = 0; p < 4; p++)
            {
                this.Controls.Remove(_players[p]);
                
                if (_playersDataForStart[p] is not null)
                {
                    _players[p] = new Player(p, 0, (Color)_playersDataForStart[p], this, ref _cells);
                    this.Controls.Add(_players[p]);
                    _players[p].BringToFront();
                }
            }

            this.Controls.Add(comboBox_Move);
            comboBox_Move.Font = new Font("Microsoft Sans Serif", (int)(DeskTop * 0.3), FontStyle.Bold);
            comboBox_Move.BackColor = Color.Wheat;
            comboBox_Move.AutoSize = true;
            comboBox_Move.BringToFront();
            comboBox_Move.Left = DeskLeft + DeskLen - comboBox_Move.Width;
            comboBox_Move.Top = DeskTop / 2 - comboBox_Move.Height / 2;

            comboBox_Move.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox_Move.Items.Add("< >");
            comboBox_Move.SelectedItem = "< >";
            object[] moves = new object[CurrentMove + 1];
            for (int m = 0; m < CurrentMove + 1; m++)
                moves[m] = m;
            comboBox_Move.Items.AddRange(moves);
            comboBox_Move.SelectedIndexChanged += ComboBox_Move_SelectedIndexChanged;
            comboBox_Move.TabIndex = 0;
        }

        private void ComboBox_Move_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (comboBox_Move.Items[0] == "< >")
                comboBox_Move.Items.Remove("< >");

            CurrentMove = (int)(comboBox_Move.SelectedItem);
            ActualPlayer = (byte)(_history[CurrentMove].actual_player);
            foreach (Panel wall in _walls)
            {
                wall.Visible = (int)(wall.Tag) <= CurrentMove;
            }
            for (int p = 0; p < 4; p++)
            {
                if (_playersDataForStart[p] is not null)
                {
                    _players[p].Visible = _history[CurrentMove].y[p] is not null;
                    if (_players[p].Visible)
                    {
                        _players[p].Cell_Y = (byte)(_history[CurrentMove].y[p]);
                        _players[p].Cell_X = (byte)(_history[CurrentMove].x[p]);
                    }
                    _players[p].Invalidate();
            
                    _stocks[p].Visible = _history[CurrentMove].stocks[p] is not null;
                    if (_stocks[p].Visible)
                    {
                        _stocks[p].Text = _history[CurrentMove].stocks[p];
                        if (p == ActualPlayer)
                        {
                            _stocks[p].BackColor = _players[ActualPlayer].BackColor;
                            _stocks[p].ForeColor = Color.FromArgb(64, 0, 0);
                        }
                        else
                        {
                            _stocks[p].BackColor = Color.FromArgb(64, 0, 0);
                            _stocks[p].ForeColor = Color.Maroon;
                        }
                    }
                }
            }
        }

        private void _MoveChooser_Click(object sender, EventArgs e)
        {
            _cts.Cancel();
        }

        private void panelOpenLog_Click(object sender, EventArgs e)
        {
            string path = $"{Application.StartupPath}log.html";
            try
            {
                Process.Start($"cmd.exe", $"/c start {path}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: can't open {path}\n\n{ex.Message}");
            }
        }
    }
}