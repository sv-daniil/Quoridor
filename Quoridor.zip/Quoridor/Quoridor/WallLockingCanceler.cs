﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Quoridor
//{
//    internal class WallLockingCanceler
//    {
//        private static char _dir;
//        private static bool _initial_move;
//        private static byte _start_y;
//        private static byte _start_x;
//        public static char Dir
//        {
//            get { return _dir; }
//            set { _dir = value; }
//        }
//        public static bool InitialMove
//        {
//            get { return _initial_move; }
//            set { _initial_move = value; }
//        }
//        public static byte Start_Y
//        {
//            get { return _start_y; }
//            set { _start_y = value; }
//        }
//        public static byte Start_X
//        {
//            get { return _start_x; }
//            set { _start_x = value; }
//        }


//        public static bool IsPlayerLocked(GameForm CallingForm, Player _player, Cell[,] _cells, byte new_wall_x, byte new_wall_y, byte new_wall_type)
//        {
//            if (_player is null)
//                return false;

//            byte real_y = _player.Cell_Y;
//            byte real_x = _player.Cell_X;
//            switch (new_wall_type)
//            {
//                case 0:
//                    _cells[new_wall_y, new_wall_x].RightWall = true;
//                    _cells[new_wall_y, new_wall_x].RightBlocked = true;
//                    _cells[new_wall_y + 1, new_wall_x].RightBlocked = true;
//                    break;
//                case 1:
//                    _cells[new_wall_y, new_wall_x].BottomtWall = true;
//                    _cells[new_wall_y, new_wall_x].BottomBlocked = true;
//                    _cells[new_wall_y, new_wall_x + 1].BottomBlocked = true;
//                    break;
//            }


//            Dir = _player.Number switch { 0 => '_', 1 => '<', 2 => '^', 3 => '>' };
//            InitialMove = true;
//            bool result = Check_along(CallingForm, _player, _cells, new_wall_x, new_wall_y, new_wall_type);

//            //_player.Cell_Y = real_y;
//            //_player.Cell_X = real_x;
//            CallingForm.MoveResults(real_x, real_y, 2);
//            switch (new_wall_type)
//            {
//                case 0:
//                    _cells[new_wall_y, new_wall_x].RightWall = false;
//                    _cells[new_wall_y, new_wall_x].RightBlocked = false;
//                    _cells[new_wall_y + 1, new_wall_x].RightBlocked = false;
//                    break;
//                case 1:
//                    _cells[new_wall_y, new_wall_x].BottomtWall = false;
//                    _cells[new_wall_y, new_wall_x].BottomBlocked = false;
//                    _cells[new_wall_y, new_wall_x + 1].BottomBlocked = false;
//                    break;
//            }
//            return result; 
//        }

//        public static bool Check_stupid(GameForm CallingForm, Player _player, Cell[,] _cells, byte new_wall_x, byte new_wall_y, byte new_wall_type)
//        {
//            _cells[_player.Cell_Y, _player.Cell_X].Tag = "available";
//            byte counted_cells = 1;
//            while (counted_cells != 0) {
//                ///
//                byte counted_cells_before = counted_cells;
//                for (byte y = 0; y < 9; y++)
//                {
//                    for (byte x = 0; x < 9; x++)
//                    {
//                        if (_cells[y, x].Tag == "available")
//                        {
//                            if (CallingForm.FromCellToSide(x, y, '^') != "wall")
//                            {
//                                _cells[y - 1, x].Tag = "available";
//                                counted_cells++;
//                            }
//                            if (CallingForm.FromCellToSide(x, y, '_') != "wall")
//                            {
//                                _cells[y + 1, x].Tag = "available";
//                                counted_cells++;
//                            }
//                            if (CallingForm.FromCellToSide(x, y, '<') != "wall")
//                            {
//                                _cells[y, x - 1].Tag = "available";
//                                counted_cells++;
//                            }
//                            if (CallingForm.FromCellToSide(x, y, '>') != "wall")
//                            {
//                                _cells[y, x + 1].Tag = "available";
//                                counted_cells++;
//                            }
//                        }
//                    }
//                }
//                if (counted_cells_before == counted_cells)
//                {
//                    counted_cells = 0;
//                }
//                ///
//            }

//            bool can_get_to_line = false;
//            switch (_player.Number) {
//                case 0:
//                    for (byte x = 0; x < 9 && !can_get_to_line; x++)
//                    {
//                        if (_cells[8, x].Tag == "available")
//                            can_get_to_line = true;
//                    }
//                    break;

//                case 1:
//                    for (byte y = 0; y < 9 && !can_get_to_line; y++)
//                    {
//                        if (_cells[y, 0].Tag == "available")
//                            can_get_to_line = true;
//                    }
//                    break;

//                case 2:
//                    for (byte x = 0; x < 9 && !can_get_to_line; x++)
//                    {
//                        if (_cells[0, x].Tag == "available")
//                            can_get_to_line = true;
//                    }
//                    break;

//                case 3:
//                    for (byte y = 0; y < 9 && !can_get_to_line; y++)
//                    {
//                        if (_cells[y, 8].Tag == "available")
//                            can_get_to_line = true;
//                    }
//                    break;
//            }

//            return !can_get_to_line;
//        }


//        public static char NextDir(char dir, byte next_in)
//        {
//            char[] dirs = ['^', '>', '_', '<'];
//            byte num = (byte)(Array.IndexOf(dirs, dir));

//            for (int i = 0; i < next_in; i++)
//            {
//                num++;
//                if (num > 3)
//                    num = 0;
//            }

//            return dirs[num];
//        }
//        public static bool Check_along(GameForm CallingForm, Player _player, Cell[,] _cells, byte new_wall_x, byte new_wall_y, byte new_wall_type)
//        {
//            while (true)
//            {
//                byte player_y = _player.Cell_Y;
//                byte player_x = _player.Cell_X;

//                if (CallingForm.FromCellToSide(player_x, player_y, NextDir(Dir, 3)) != "wall" && !InitialMove)
//                {
//                    Dir = NextDir(Dir, 3);
//                }
//                else if (CallingForm.FromCellToSide(player_x, player_y, Dir) == "wall")
//                {
//                    if (InitialMove)
//                    {
//                        InitialMove = false;
//                        Start_Y = player_y;
//                        Start_X = player_x;
//                    }
//                    if (CallingForm.FromCellToSide(player_x, player_y, NextDir(Dir, 1)) != "wall")
//                    {
//                        Dir = NextDir(Dir, 1);
//                    }
//                    else if (CallingForm.FromCellToSide(player_x, player_y, NextDir(Dir, 2)) != "wall")
//                    {
//                        Dir = NextDir(Dir, 2);
//                    }
//                    else if (CallingForm.FromCellToSide(player_x, player_y, NextDir(Dir, 3)) != "wall")
//                    {
//                        Dir = NextDir(Dir, 3);
//                    }
//                    else
//                    {
//                        //await CallingForm.LockingWarning();
//                        return true;
//                    }
//                }
//                //MessageBox.Show($"I'm going to walk {Dir}\nInitialMove = {InitialMove}");

//                switch (Dir) // ------ delete ------
//                {
//                    case '^': CallingForm.MoveResults((byte)(player_x), (byte)(player_y - 1), 2); break;
//                    case '_': CallingForm.MoveResults((byte)(player_x), (byte)(player_y + 1), 2); break;
//                    case '<': CallingForm.MoveResults((byte)(player_x - 1), (byte)(player_y), 2); break;
//                    case '>': CallingForm.MoveResults((byte)(player_x + 1), (byte)(player_y), 2); break;
//                }

//                player_y = _player.Cell_Y;
//                player_x = _player.Cell_X;
//                if (player_y == Start_Y && player_x == Start_X)
//                {
//                    //await CallingForm.LockingWarning();
//                    return true;
//                }
//                if ((_player.Number == 0 && _player.Cell_Y == 8) ||
//                    (_player.Number == 1 && _player.Cell_X == 0) ||
//                    (_player.Number == 2 && _player.Cell_Y == 0) ||
//                    (_player.Number == 3 && _player.Cell_X == 8))
//                {
//                    return false;
//                }
//            }

//            return false;
//        }
//    }
//}
